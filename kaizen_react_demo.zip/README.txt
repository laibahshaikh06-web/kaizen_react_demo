Kaizen Mental Health — React Demo (Vite)

Contents:
- package.json
- index.html
- src/main.jsx
- src/App.jsx
- src/styles.css

How to run locally:
1. Install Node.js (v18+) and npm.
2. In the project folder, run:
   npm install
   npm run dev
3. Open the URL shown in the terminal (usually http://localhost:5173).

How to deploy (quick options):
- Vercel: create a GitHub repo, push this project, import on vercel.com and deploy (Vite is auto-detected).
- Netlify: similar flow, connect GitHub repo and deploy.

Notes:
- This is a front-end prototype only (no backend). The AI chat and crisis alert are mocked (alerts).
- You can customize branding colors and add real backend later.
