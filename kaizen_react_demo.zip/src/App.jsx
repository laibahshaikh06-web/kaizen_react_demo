import React, { useState } from "react";

const styles = {
  page: {
    minHeight: "100vh",
    background: "linear-gradient(#fbf7f1, #ffffff)",
    padding: "24px",
    fontFamily: "Inter, sans-serif",
    display: "flex",
    justifyContent: "center",
    alignItems: "flex-start"
  },
  card: {
    width: "920px",
    borderRadius: "18px",
    padding: "20px",
    background: "#fff",
    boxShadow: "0 10px 30px rgba(0,0,0,0.06)"
  },
  headerRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "12px"
  },
  logo: {
    display: "flex",
    alignItems: "center",
    gap: "12px"
  },
  logoCircle: {
    width: "56px",
    height: "56px",
    borderRadius: "50%",
    background: "linear-gradient(135deg,#8b5cf6,#ec4899)",
    color: "white",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: 700
  },
  btnPrimary: {
    background: "#4f46e5",
    color: "white",
    padding: "10px 14px",
    borderRadius: "10px",
    border: "none",
    cursor: "pointer"
  },
  btnBorder: {
    background: "transparent",
    color: "#333",
    padding: "10px 14px",
    borderRadius: "10px",
    border: "1px solid #ddd",
    cursor: "pointer"
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "2fr 1fr",
    gap: "16px"
  },
  box: {
    padding: "14px",
    borderRadius: "12px",
    border: "1px solid #eee",
    background: "#faf9f6"
  },
  smallBtn: {
    padding: "8px 10px",
    borderRadius: "8px",
    border: "none",
    cursor: "pointer"
  },
  chatBox: {
    height: "220px",
    overflow: "auto",
    padding: "12px",
    borderRadius: "10px",
    background: "#fff",
    border: "1px solid #eee"
  }
};

export default function App(){
  const [screen, setScreen] = useState("onboarding");
  const [mood, setMood] = useState(3);
  const [points, setPoints] = useState(120);
  const [streak, setStreak] = useState(4);
  const moodEmojis = ["😞","😕","😐","🙂","😄"];

  function Header({title}){
    return (
      <div style={styles.headerRow}>
        <div style={styles.logo}>
          <div style={styles.logoCircle}>KZ</div>
          <div>
            <div style={{fontWeight:700}}>{title}</div>
            <div style={{fontSize:13, color:"#666"}}>Kaizen — Mental Health</div>
          </div>
        </div>
        <div style={{display:"flex", gap:10}}>
          <button style={styles.btnBorder} onClick={()=>setScreen("onboarding")}>Home</button>
          <button style={styles.btnBorder} onClick={()=>setScreen("dashboard")}>Dashboard</button>
        </div>
      </div>
    );
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        {screen === "onboarding" && (
          <>
            <Header title="Welcome" />
            <div style={{display:"flex", gap:20, alignItems:"center"}}>
              <div style={{flex:1}}>
                <h2 style={{margin:0}}>Kaizen Mental Health</h2>
                <p style={{color:"#555"}}>Private, stigma-free support for students.</p>
                <p style={{color:"#555"}}>Sign in or continue anonymously to get personalized support.</p>
                <div style={{display:"flex", gap:12, marginTop:12}}>
                  <button style={styles.btnPrimary} onClick={()=>setScreen("signup")}>Sign in (Student ID)</button>
                  <button style={styles.btnBorder} onClick={()=>setScreen("dashboard")}>Continue Anonymously</button>
                </div>
                <ul style={{marginTop:18, color:"#444"}}>
                  <li>Digital twin counselor</li>
                  <li>Early stress detection</li>
                  <li>Context-aware nudges & gamification</li>
                </ul>
              </div>
              <div style={{width:220, textAlign:"center"}}>
                <div style={{fontSize:48}}>🌿</div>
                <div style={{color:"#777", marginTop:8}}>Be kind to your mind</div>
              </div>
            </div>
          </>
        )}

        {screen === "signup" && (
          <>
            <Header title="Create Profile" />
            <div style={{display:"flex", flexDirection:"column", gap:12}}>
              <label>How often do you feel stressed?</label>
              <select style={{padding:10, borderRadius:8, border:"1px solid #ddd"}}>
                <option>Rarely</option>
                <option>Sometimes</option>
                <option>Often</option>
                <option>Almost every day</option>
              </select>
              <label>Study load (hrs/day)</label>
              <input type="number" defaultValue={4} style={{padding:10, borderRadius:8, border:"1px solid #ddd"}} />
              <div style={{display:"flex", gap:10}}>
                <button style={styles.btnPrimary} onClick={()=>setScreen("dashboard")}>Finish</button>
                <button style={styles.btnBorder} onClick={()=>setScreen("onboarding")}>Back</button>
              </div>
            </div>
          </>
        )}

        {screen === "dashboard" && (
          <>
            <Header title="Dashboard — Stress Overview" />
            <div style={styles.grid}>
              <div style={styles.box}>
                <h4 style={{marginTop:0}}>Daily Mood Check</h4>
                <div style={{display:"flex", alignItems:"center", gap:12}}>
                  <input type="range" min="1" max="5" value={mood} onChange={(e)=>setMood(Number(e.target.value))} style={{flex:1}} />
                  <div style={{fontSize:26}}>{moodEmojis[mood-1]}</div>
                </div>

                <div style={{marginTop:16}}>
                  <h5 style={{margin:0}}>Stress Trend</h5>
                  <div style={{height:80, display:"flex", alignItems:"flex-end", gap:6, marginTop:8}}>
                    { [3,2,4,3,5,2,3].map((v,i)=>(
                      <div key={i} style={{flex:1, height: v*14, borderRadius:6, background: `linear-gradient(180deg, rgba(99,102,241,0.9), rgba(236,72,153,0.6))`}} />
                    )) }
                  </div>
                </div>

                <div style={{marginTop:14, display:"flex", gap:10}}>
                  <button style={{...styles.smallBtn, background:"#10b981", color:"#fff", borderRadius:8}} onClick={()=>setScreen("interventions")}>Get Intervention</button>
                  <button style={{...styles.smallBtn, border:"1px solid #ddd", borderRadius:8}} onClick={()=>setScreen("chatbot")}>Talk to AI Counselor</button>
                </div>
              </div>

              <div style={styles.box}>
                <h4 style={{marginTop:0}}>Well-being Score</h4>
                <div style={{display:"flex", alignItems:"center", gap:12}}>
                  <div style={{fontSize:28, fontWeight:700}}>{Math.max(0,100 - mood*10)}</div>
                  <div style={{color:"#777"}}>Score (higher = better)</div>
                </div>

                <div style={{marginTop:12}}>
                  <div style={{display:"flex", justifyContent:"space-between"}}>
                    <div>
                      <div style={{fontSize:20, fontWeight:700}}>{points}</div>
                      <div style={{fontSize:12, color:"#777"}}>Points</div>
                    </div>
                    <div style={{textAlign:"right"}}>
                      <div style={{fontSize:20, fontWeight:700}}>{streak}d</div>
                      <div style={{fontSize:12, color:"#777"}}>Streak</div>
                    </div>
                  </div>
                  <button style={{marginTop:12, padding:10, borderRadius:10, background:"#facc15", border:"none", cursor:"pointer"}} onClick={()=>{ setPoints(points+10); setStreak(streak+1); }}>Complete a Check-in (+10)</button>
                </div>
              </div>
            </div>

            <div style={{marginTop:14, display:"flex", gap:10}}>
              <button style={styles.btnBorder} onClick={()=>setScreen("peerspace")}>Peer Spaces</button>
              <button style={styles.btnBorder} onClick={()=>setScreen("settings")}>Settings</button>
            </div>
          </>
        )}

        {screen === "interventions" && (
          <>
            <Header title="Interventions & Nudges" />
            <div style={{display:"flex", flexDirection:"column", gap:12}}>
              <div style={{padding:12, borderRadius:10, background:"#eef2ff"}}>
                <h5 style={{margin:0}}>Quick 5-min breathing</h5>
                <p style={{color:"#555"}}>Guided breathing exercise to reduce anxiety.</p>
                <div style={{display:"flex", gap:10, marginTop:8}}>
                  <button style={styles.btnPrimary} onClick={()=>alert("Pretend breathing exercise started")}>Start</button>
                  <button style={styles.btnBorder} onClick={()=>setScreen("dashboard")}>Dismiss</button>
                </div>
              </div>

              <div style={{padding:12, borderRadius:10, background:"#fff0f6"}}>
                <h5 style={{margin:0}}>Study-break nudge</h5>
                <p style={{color:"#555"}}>You studied 2.5 hrs. Take a 10-min walk & hydrate.</p>
                <div style={{display:"flex", gap:10, marginTop:8}}>
                  <button style={{...styles.smallBtn, background:"#10b981", color:"#fff", borderRadius:8}} onClick={()=>setPoints(points+5)}>Mark as Done (+5)</button>
                  <button style={styles.btnBorder} onClick={()=>setScreen("dashboard")}>Later</button>
                </div>
              </div>
            </div>
          </>
        )}

        {screen === "chatbot" && (
          <>
            <Header title="AI Counselor (Chat)"/>
            <div style={{display:"flex", flexDirection:"column", gap:10}}>
              <div style={styles.chatBox}>
                <div style={{fontSize:12, color:"#666"}}>AI Counselor: Hi — tell me how you're feeling today.</div>
                <div style={{marginTop:8}}>User: I'm feeling overwhelmed with assignments.</div>
                <div style={{marginTop:8, color:"#333"}}>AI: Try breaking tasks into 25-min blocks. Prioritize 3 tasks today. Want a guided plan?</div>
              </div>
              <div style={{display:"flex", gap:8}}>
                <input placeholder="Type a message" style={{flex:1, padding:10, borderRadius:8, border:"1px solid #ddd"}} />
                <button style={styles.btnPrimary}>Send</button>
              </div>
              <div style={{display:"flex", gap:10}}>
                <button style={styles.btnBorder} onClick={()=>setScreen("dashboard")}>Back</button>
                <button style={{...styles.btnPrimary, background:"#ef4444"}} onClick={()=>alert("Crisis alert sent to campus counsellor")}>Crisis Alert</button>
              </div>
            </div>
          </>
        )}

        {screen === "peerspace" && (
          <>
            <Header title="Peer Support Spaces"/>
            <div style={{display:"flex", flexDirection:"column", gap:12}}>
              <div style={{padding:12, borderRadius:10, background:"#fff"}}>
                <h5 style={{margin:0}}>Exam Stress — Room</h5>
                <p style={{color:"#555"}}>Moderated room to share study tips & vent safely.</p>
                <div style={{display:"flex", gap:8, marginTop:8}}>
                  <button style={styles.btnPrimary}>Join</button>
                  <button style={styles.btnBorder} onClick={()=>setScreen("dashboard")}>Back</button>
                </div>
              </div>
              <div style={{padding:12, borderRadius:10, background:"#fff"}}>
                <h5 style={{margin:0}}>Sleep & Routine</h5>
                <p style={{color:"#555"}}>Share bedtime routines that work.</p>
                <div style={{display:"flex", gap:8, marginTop:8}}>
                  <button style={styles.btnPrimary}>Join</button>
                </div>
              </div>
            </div>
          </>
        )}

        {screen === "settings" && (
          <>
            <Header title="Settings & Privacy"/>
            <div style={{display:"flex", flexDirection:"column", gap:12}}>
              <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
                <div>
                  <div style={{fontWeight:700}}>Anonymous Mode</div>
                  <div style={{fontSize:12, color:"#666"}}>No personal data stored</div>
                </div>
                <input type="checkbox" defaultChecked />
              </div>

              <div>
                <div style={{fontWeight:700}}>Data Export</div>
                <div style={{fontSize:12, color:"#666"}}>Download your anonymized reports</div>
                <div style={{marginTop:8}}>
                  <button style={styles.btnBorder}>Export</button>
                </div>
              </div>

              <div style={{display:"flex", gap:10}}>
                <button style={styles.btnBorder} onClick={()=>setScreen("dashboard")}>Back</button>
                <button style={{...styles.btnBorder, background:"#fee2e2"}}>Logout</button>
              </div>
            </div>
          </>
        )}

      </div>
    </div>
  );
}
